export class Items{

    constructor(public name:string,public amount:number){}
}

  