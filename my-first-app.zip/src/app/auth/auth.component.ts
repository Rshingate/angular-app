import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {AuthService} from './auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {

  isLogin = true;
  error :string = null;
  isLoading:boolean = false;

  constructor(private authService:AuthService
    ) { }

  ngOnInit() {
  }

  switchForms(){
    this.isLogin = !this.isLogin;
  }

  onSubmit(form:NgForm){

  if(!form.valid)
  {
    return;
  }  

   var email = form.value.email;
   var password = form.value.password

   this.isLoading = true;

  if(this.isLogin){
    this.authService.login(email,password).subscribe(data => {
      this.isLoading = false;
     },
     errorMessage  => {
       this.error = errorMessage;
       this.isLoading = false;
     }
     )
  } 
  else{
    this.authService.signUp(email,password).subscribe(data => {
      this.isLoading = false;
     },
     errorMessage  => {
       this.error = errorMessage;
       this.isLoading = false;
     }
     )
  }
  
    form.reset()

  }
}
