import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http:HttpClient){}

  signUp(email:string,password:string)
  {
      return this.http.post('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyAlydrlF8l_rfYjOkj43-DLMBuevP-ag8I',
      {
        email:email,
        password : password,
        returnSecureToken : true
      }
      )
      .pipe((catchError(errorResponse  => {
          let errorMessage = ''
          if(errorResponse.error.error.message = 'EMAIL_EXISTS')
          {
            errorMessage = 'Email Already Exists!!';
          }
          return throwError(errorMessage);
      })));
  }

  login(email:string,password:string)
  {
      return this.http.post('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyAlydrlF8l_rfYjOkj43-DLMBuevP-ag8I',
      {
        email:email,
        password : password,
        returnSecureToken : true
      }
      )
      .pipe((catchError(errorResponse  => {
          let errorMessage = ''
          if(errorResponse.error.error.message = 'EMAIL_NOT_FOUND')
          {
            errorMessage = 'Email Not Found!!';
          }
          return throwError(errorMessage);
      })));
  }

}
